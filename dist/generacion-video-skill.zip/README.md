# Skill: generacion-video

Skill de AutoViral AI para cargar en Claude Desktop.

- **Nombre:** `generacion-video`
- **Versión:** 1.0.0
- **Descripción:** Ejecuta el pipeline técnico de producción de un video corto desde un guion confirmado: audio (edge-tts), transcripción (.srt), imágenes por escena (Gemini) y ensamblado final (FFmpeg/Kinocut). Fase 2.

## Carga en Claude Desktop

Importa este `.zip` desde la configuración de skills de Claude Desktop. Las instrucciones del
sistema están en `instructions.md`.

## Cómo se usa

Carga la skill cuando el usuario indique que quiere crear/refinar una idea de video
(`ideacion-video`) o producir un video a partir de un guion confirmado (`generacion-video`).

---
Proyecto: AutoViral AI · Licencia MIT
