# Skill: ideacion-video

Skill de AutoViral AI para cargar en Claude Desktop.

- **Nombre:** `ideacion-video`
- **Versión:** 1.0.0
- **Descripción:** Guía al usuario desde una idea vaga (o sin idea) hasta un guion de video corto final, estructurado y confirmado. Fase 1: ideación y redacción. Nunca genera audio, imágenes ni video.

## Carga en Claude Desktop

Importa este `.zip` desde la configuración de skills de Claude Desktop. Las instrucciones del
sistema están en `instructions.md`.

## Cómo se usa

Carga la skill cuando el usuario indique que quiere crear/refinar una idea de video
(`ideacion-video`) o producir un video a partir de un guion confirmado (`generacion-video`).

---
Proyecto: AutoViral AI · Licencia MIT
